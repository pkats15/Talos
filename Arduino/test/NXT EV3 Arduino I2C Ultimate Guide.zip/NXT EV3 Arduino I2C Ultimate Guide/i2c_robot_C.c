// Set the sensor port 1 (S1) to be a custom I2C sensor
#pragma config(Sensor, S1,TIR,sensorI2CCustom)

// Allow us to use "ARDUINO_PORT" instead of writing "S1"
#define ARDUINO_PORT S1


//___________________________ ____________ ________________________________________
//___________________________|            |________________________________________
//___________________________| I2C Basics |________________________________________
//___________________________|____________|________________________________________

// First, define the Arduino Address
// Address is 0x04 on the Arduino: (Binary) 0100
// Bit shifted out with one 0, that becomes: (Binary) 1000
// Which is 0x08
#define ARDUINO_ADDRESS	0x08     // Arduino: 0x04


ubyte I2Cmessage[22];
char I2Creply[20];

int i2c_msg(byte ard_address, int message_size, int return_size, ubyte byte0, ubyte byte1, ubyte byte2, ubyte byte3 ,ubyte byte4)
{
	memset(I2Creply, 0, sizeof(I2Creply));
	message_size = message_size+3;

	I2Cmessage[0] = message_size; // Messsage Size
	I2Cmessage[1] = ard_address;

	I2Cmessage[2] = byte0;
	I2Cmessage[3] = byte1;
	I2Cmessage[4] = byte2;
	I2Cmessage[5] = byte3;
	I2Cmessage[6] = byte4; // max is 99 only for I2Cmessage[6]
	//// can't add more than 5 Bytes

	sendI2CMsg(S1, &I2Cmessage[0], return_size);
	wait1Msec(20);

	readI2CReply(ARDUINO_PORT, &I2Creply[0], return_size);


	int x = I2Creply[0];

	wait1Msec(35);
	return x;
}

//___________________________ ___________________ _________________________________
//___________________________|                   |_________________________________
//___________________________| Devices Functions |_________________________________
//___________________________|___________________|_________________________________

void set_light(byte address, int pin_num , bool state)
{
	i2c_msg(address, 2, 0, 1, pin_num, state, 0, 0);
}

//_________________________________________________________________________________

void set_servo_motor(byte address, int pin_num, int angle)
{
	i2c_msg(address, 2, 0, 2, pin_num, angle, 0, 0);
}

//_________________________________________________________________________________

void set_dc_motor(byte address, int pin1_num, int pin2_num,int speed)
{
	int speed1 = 0;
	int speed2 = 0;

	if( speed > 99 )
		speed = 99;
	else if ( speed < -99 )
		speed = -99;

	if ( speed > 0 )
		speed1 = abs(speed);
	else
		speed2 = abs(speed);

	i2c_msg(address, 3, 0, 4, pin1_num, speed1, pin2_num, speed2);
}

//_________________________________________________________________________________

int read_sensor(byte address, int pin_num, bool analog_digital)
{
	int value = i2c_msg(address, 2, 1, 4, pin_num, analog_digital , 0, 0);
	return value;
}

//___________________________ _________ ___________________________________________
//___________________________|         |___________________________________________
//___________________________| Example |___________________________________________
//___________________________|_________|___________________________________________



task main()
{
	int ultrasonic_value;
	int x,y;

	while(true)
	{
		// Set servo to 90 degrees
		set_servo_motor( ARDUINO_ADDRESS, 11, 90 );

		// Wait 1 second
		wait1Msec(1000);

		ultrasonic_value = read_sensor( ARDUINO_ADDRESS, 0, true);

		if( ultrasonic_value > 25 )
		{
			//Move forward
			set_dc_motor( ARDUINO_ADDRESS, 5, 6, 100);
			set_dc_motor( ARDUINO_ADDRESS, 9, 10, 100);

		}
		else
		{
			//Stop the robot
			set_dc_motor( ARDUINO_ADDRESS, 5, 6, 0);
			set_dc_motor( ARDUINO_ADDRESS, 9, 10, 0);

			//Turn LED on
			set_light( ARDUINO_ADDRESS, 2, true);

			//Set servo to 45 degrees
			set_servo_motor( ARDUINO_ADDRESS, 11, 45 );

			// Wait 1 second
			wait1Msec(1000);

			ultrasonic_value = read_sensor( ARDUINO_ADDRESS, 0, true);
			x = ultrasonic_value;

			//Set servo to 135 degrees
			set_servo_motor( ARDUINO_ADDRESS, 11, 135 );

			// Wait 1 second
			wait1Msec(1000);

			ultrasonic_value = read_sensor( ARDUINO_ADDRESS, 0, true);
			y = ultrasonic_value;

			if ( x > y )
			{
				//	Turn to the right a little
				set_dc_motor( ARDUINO_ADDRESS, 5, 6, 100);
				set_dc_motor( ARDUINO_ADDRESS, 9, 10, -100);
			}
			else
			{
				//	Turn to the left a little
				set_dc_motor( ARDUINO_ADDRESS, 5, 6, -100);
				set_dc_motor( ARDUINO_ADDRESS, 9, 10, 100);
			}

			wait1Msec(1500);
			set_dc_motor( ARDUINO_ADDRESS, 5, 6, 0);
			set_dc_motor( ARDUINO_ADDRESS, 9, 10, 0);


			//Turn LED off
			set_light( ARDUINO_ADDRESS, 2, false);
		}

	}
}
